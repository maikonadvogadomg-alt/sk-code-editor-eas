# SK Code Editor — Versão Vercel

Esta é a versão adaptada do SK Code Editor para deploy na Vercel.

## O que funciona na Vercel

- Assistente Jurídico completo (Processar, Ementas, Histórico, Ações personalizadas)
- Import de PDF/DOCX/TXT para análise
- Esforço 1-5 + Verbosidade
- Ditado por voz (nativo do navegador)
- Chaves próprias (Groq, OpenAI, Anthropic, Gemini, etc.)
- Modo Demo (requer OPENAI_API_KEY como variável de ambiente)
- Campo Livre (assistente geral)

## O que NÃO funciona na Vercel

- Terminal de comando (bash)
- Editor Monaco com sistema de arquivos virtual
- `npm install` de pacotes
- Execução de código (Node.js/Python)
- Preview ao vivo

Para essas funções, use a versão completa no Replit.

## Como fazer o deploy

### 1. Instalar dependências
```bash
npm install
```

### 2. Instalar pacotes para melhor suporte a PDF/DOCX (opcional)
```bash
npm install pdf-parse mammoth @vercel/node
npm install -D @types/node
```

### 3. Variáveis de ambiente no Vercel

No painel da Vercel → Settings → Environment Variables, adicione:

| Variável | Valor | Descrição |
|----------|-------|-----------|
| `OPENAI_API_KEY` | `sk-...` | Chave OpenAI para modo Demo |

Se não tiver essa chave, o modo Demo não funciona — mas com **chave própria** do usuário funciona normalmente.

### 4. Fazer o deploy

```bash
# Instalar Vercel CLI
npm i -g vercel

# Deploy
vercel

# Ou conectar o GitHub e fazer deploy automático pelo painel da Vercel
```

### 5. Configuração automática

O arquivo `vercel.json` já está configurado para:
- Servir o frontend React (Vite)
- Rotear `/api/*` para as funções serverless
- Suporte a streaming de IA (Edge Functions)

## Notas importantes

- As Edge Functions (`/api/legal/process` e `/api/legal/refine`) suportam **streaming SSE** na Vercel
- O plano gratuito da Vercel tem limite de 10s por função (Edge Functions têm mais)
- Para transcrição de áudio: o usuário precisa ter chave Groq ou OpenAI própria
- Ementas, histórico e chaves ficam salvas no localStorage do navegador do usuário

## Estrutura do projeto

```
/
├── api/
│   ├── legal/
│   │   ├── process.ts    ← Processamento jurídico (Edge)
│   │   └── refine.ts     ← Chat de refinamento (Edge)
│   └── upload/
│       └── extract-text.ts ← Extração de texto de arquivos
├── src/                  ← Frontend React
│   ├── components/
│   │   ├── AssistenteJuridico.tsx
│   │   ├── CampoLivre.tsx
│   │   └── ...
│   └── ...
├── public/
├── index.html
├── vite.config.ts
├── package.json
├── tsconfig.json
└── vercel.json
```
