// Vercel Function — POST /api/upload/extract-text
// Extrai texto de arquivos TXT, MD, PDF (básico) e DOCX
// Nota: Para PDF/DOCX completo instale: npm install pdf-parse mammoth

import type { VercelRequest, VercelResponse } from "@vercel/node";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ message: "Method not allowed" });

  res.setHeader("Access-Control-Allow-Origin", "*");

  try {
    // Lê o body como buffer
    const chunks: Buffer[] = [];
    for await (const chunk of req) chunks.push(chunk as Buffer);
    const body = Buffer.concat(chunks);

    // Encontra o content-type boundary
    const contentType = req.headers["content-type"] || "";
    const boundaryMatch = contentType.match(/boundary=(.+)/);
    if (!boundaryMatch) return res.status(400).json({ message: "Multipart boundary não encontrado." });

    const boundary = boundaryMatch[1];
    const parts = parseMultipart(body, boundary);

    if (parts.length === 0) return res.status(400).json({ message: "Nenhum arquivo recebido." });

    const results: string[] = [];

    for (const part of parts) {
      const filename = part.filename || "arquivo";
      const ext = filename.split(".").pop()?.toLowerCase() || "";

      if (ext === "txt" || ext === "md" || ext === "csv") {
        results.push(part.data.toString("utf-8"));
      } else if (ext === "pdf") {
        // Tentativa básica de extração de texto de PDF (sem biblioteca)
        const text = extractTextFromPdfBuffer(part.data);
        if (text) results.push(text);
        else results.push(`[PDF: ${filename} — instale pdf-parse para extração completa]`);
      } else if (ext === "docx" || ext === "doc") {
        results.push(`[DOCX: ${filename} — instale mammoth para extração de Word]`);
      } else if (ext === "rtf") {
        const text = part.data.toString("utf-8").replace(/\{\\[^{}]*\}|\\[a-z]+\d* ?|[{}]/g, "").trim();
        results.push(text);
      } else {
        results.push(part.data.toString("utf-8"));
      }
    }

    const combined = results.filter(Boolean).join("\n\n");
    if (!combined.trim()) return res.status(422).json({ message: "Arquivo sem texto legível." });

    return res.json({ text: combined });
  } catch (e: any) {
    return res.status(500).json({ message: e.message });
  }
}

// Parser multipart simples
function parseMultipart(body: Buffer, boundary: string): Array<{ filename: string; data: Buffer }> {
  const sep = Buffer.from(`--${boundary}`);
  const results: Array<{ filename: string; data: Buffer }> = [];
  let start = 0;
  while (start < body.length) {
    const idx = body.indexOf(sep, start);
    if (idx === -1) break;
    start = idx + sep.length;
    if (body[start] === 45 && body[start + 1] === 45) break; // --
    if (body[start] === 13) start += 2; // CRLF
    const headerEnd = body.indexOf(Buffer.from("\r\n\r\n"), start);
    if (headerEnd === -1) break;
    const headers = body.slice(start, headerEnd).toString();
    const filenameMatch = headers.match(/filename="([^"]+)"/);
    const filename = filenameMatch ? filenameMatch[1] : "arquivo";
    start = headerEnd + 4;
    const nextBoundary = body.indexOf(sep, start);
    const dataEnd = nextBoundary === -1 ? body.length : nextBoundary - 2;
    const data = body.slice(start, dataEnd);
    results.push({ filename, data });
    start = nextBoundary === -1 ? body.length : nextBoundary;
  }
  return results;
}

// Extração básica de texto de PDF (sem biblioteca externa)
function extractTextFromPdfBuffer(buffer: Buffer): string {
  try {
    const str = buffer.toString("latin1");
    const texts: string[] = [];
    const re = /BT[\s\S]*?ET/g;
    let match;
    while ((match = re.exec(str)) !== null) {
      const block = match[0];
      const tjRe = /\(((?:[^()\\]|\\.)*)\)\s*Tj/g;
      let tm;
      while ((tm = tjRe.exec(block)) !== null) {
        const raw = tm[1].replace(/\\n/g, "\n").replace(/\\r/g, "").replace(/\\\(/g, "(").replace(/\\\)/g, ")").replace(/\\\\/g, "\\");
        if (raw.trim()) texts.push(raw.trim());
      }
    }
    return texts.join(" ").substring(0, 100000);
  } catch { return ""; }
}
