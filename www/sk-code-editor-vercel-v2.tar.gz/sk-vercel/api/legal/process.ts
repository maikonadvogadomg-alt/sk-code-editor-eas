// Vercel Edge Function — POST /api/legal/process
// Processa texto jurídico com ação e resposta em streaming SSE
export const config = { runtime: "edge" };

const SYSTEM_PROMPT = `Voce e Jamile, assistente juridica especializada em direito brasileiro.
Voce auxilia advogados na elaboracao de documentos juridicos.
REGRAS:
- Documentos juridicos: use recuo de 4cm na margem esquerda do primeiro paragrafo
- Linguagem formal e tecnica
- Nunca invente dados, fatos, nomes, datas, valores ou jurisprudencia
- Se o usuario fornecer jurisprudencia, cite-a literalmente e fielmente
- Para minutas e peticoes: desenvolva completamente todos os topicos e argumentos
- Responda sempre em portugues brasileiro`;

const ACTION_PROMPTS: Record<string, string> = {
  "resumir":        "Faca um resumo juridico objetivo e completo do documento.\n\nDOCUMENTO:\n{{texto}}",
  "revisar":        "Revise o documento juridico apontando erros e sugerindo melhorias.\n\nDOCUMENTO:\n{{texto}}",
  "refinar":        "Reescreva o documento de forma mais clara e profissional.\n\nDOCUMENTO:\n{{texto}}",
  "simplificar":    "Traduza este documento juridico para linguagem acessivel ao cliente leigo.\n\nDOCUMENTO:\n{{texto}}",
  "minuta":         "Com base no texto abaixo, elabore uma minuta juridica completa.\n\nTEXTO:\n{{texto}}",
  "analisar":       "Analise juridicamente o documento, identificando pontos fortes, fracos e riscos.\n\nDOCUMENTO:\n{{texto}}",
  "modo-estrito":   "Corrija apenas erros de portugues e estilo, sem alterar o conteudo juridico.\n\nDOCUMENTO:\n{{texto}}",
  "modo-redacao":   "Melhore o texto tornando-o mais profissional e persuasivo, mantendo todos dados e fatos.\n\nTEXTO:\n{{texto}}",
  "modo-interativo":"Identifique lacunas e pontos que precisam complementacao pelo advogado.\n\nTEXTO:\n{{texto}}",
};

const EFFORT_INSTRUCTIONS: Record<number, string> = {
  1: "ESFORCO: RAPIDO. Direto e objetivo. Versao concisa e funcional.",
  2: "ESFORCO: BASICO. Pontos principais bem desenvolvidos.",
  3: "ESFORCO: DETALHADO. Analise completa. Desenvolva cada argumento extensamente.",
  4: "ESFORCO: PROFUNDO. Fundamentacao robusta, nuances, toda legislacao relevante.",
  5: "ESFORCO: EXAUSTIVO. Todos os angulos, todas as teses, toda a jurisprudencia aplicavel.",
};

const AUTO_DETECT_PROVIDERS: [string, string, string][] = [
  ["gsk_",   "https://api.groq.com/openai/v1",       "llama-3.3-70b-versatile"],
  ["sk-or-", "https://openrouter.ai/api/v1",          "openai/gpt-4o-mini"],
  ["pplx-",  "https://api.perplexity.ai",             "llama-3.1-sonar-large-128k-online"],
  ["AIza",   "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash"],
  ["xai-",   "https://api.x.ai/v1",                  "grok-3-mini"],
  ["sk-ant", "https://api.anthropic.com/v1",          "claude-3-5-haiku-20241022"],
  ["sk-",    "https://api.openai.com/v1",             "gpt-4o-mini"],
];

function detectProvider(key: string): { url: string; model: string } | null {
  for (const [prefix, url, model] of AUTO_DETECT_PROVIDERS) {
    if (key.startsWith(prefix)) return { url, model };
  }
  return null;
}

function buildSystemPrompt(effort: number, verbosity: "curta" | "longa"): string {
  const effortInstr = EFFORT_INSTRUCTIONS[effort] || EFFORT_INSTRUCTIONS[3];
  const verbInstr = verbosity === "curta"
    ? "TAMANHO: CONCISO. Direto ao ponto."
    : "TAMANHO: COMPLETO. Desenvolva cada argumento extensamente. Minimo 15 paginas para minutas.";
  return SYSTEM_PROMPT + "\n\n" + effortInstr + "\n" + verbInstr;
}

function effortToMaxTokens(effort: number, verbosity: "curta" | "longa"): number {
  const base: Record<number, number> = { 1: 8192, 2: 16384, 3: 32768, 4: 65536, 5: 131072 };
  const tokens = base[effort] || 16384;
  return verbosity === "curta" ? Math.min(tokens, 32768) : tokens;
}

const DEMO_KEY   = process.env.OPENAI_API_KEY || "";
const DEMO_URL   = "https://api.openai.com/v1";
const DEMO_MODEL = "gpt-4o-mini";

export default async function handler(request: Request): Promise<Response> {
  if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });

  let body: any;
  try { body = await request.json(); } catch { return new Response("Invalid JSON", { status: 400 }); }

  const { text, action, effortLevel, verbosity, customKey, customUrl, customModel, jurisText, customPrompt } = body;

  if (!text?.trim()) return new Response(JSON.stringify({ message: "Texto é obrigatório." }), { status: 400 });

  const effort = Math.min(5, Math.max(1, Number(effortLevel) || 3));
  const verb: "curta" | "longa" = verbosity === "curta" ? "curta" : "longa";
  const maxTokens = effortToMaxTokens(effort, verb);

  const template = customPrompt
    ? customPrompt + "\n\nTEXTO:\n{{texto}}"
    : ACTION_PROMPTS[action];
  if (!template) return new Response(JSON.stringify({ message: `Ação desconhecida: ${action}` }), { status: 400 });

  const jurisPart = jurisText?.trim()
    ? `\n\nJURISPRUDENCIA FORNECIDA PELO ADVOGADO (cite literalmente):\n${jurisText.trim()}`
    : "";
  const fullText = text.trim() + jurisPart;
  const userPrompt = template.replace("{{texto}}", fullText);
  const systemPrompt = buildSystemPrompt(effort, verb);

  // Escolhe provider
  const cleanKey = (customKey || "").trim();
  let apiUrl: string;
  let apiModel: string;
  let apiKey: string;
  let isDemo = false;

  if (cleanKey) {
    const detected = detectProvider(cleanKey);
    apiUrl   = (customUrl || detected?.url || "https://api.openai.com/v1").replace(/\/$/, "");
    apiModel = customModel || detected?.model || "gpt-4o-mini";
    apiKey   = cleanKey;
  } else {
    apiUrl   = DEMO_URL;
    apiModel = DEMO_MODEL;
    apiKey   = DEMO_KEY;
    isDemo   = true;
  }

  if (!apiKey) {
    return new Response(JSON.stringify({ message: "Configure OPENAI_API_KEY nas variáveis de ambiente do Vercel para usar o modo Demo." }), { status: 503 });
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (data: object) => {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
      };

      try {
        send({ mode: isDemo ? "demo" : "custom" });

        const resp = await fetch(`${apiUrl}/chat/completions`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: apiModel,
            max_tokens: maxTokens,
            temperature: 0.7,
            stream: true,
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user",   content: userPrompt },
            ],
          }),
        });

        if (!resp.ok) {
          const err = await resp.text();
          send({ error: `Erro ${resp.status}: ${err.substring(0, 200)}` });
          controller.close(); return;
        }

        const reader = resp.body?.getReader();
        if (!reader) { send({ error: "Sem resposta do provider." }); controller.close(); return; }

        const dec = new TextDecoder(); let buf = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n"); buf = lines.pop() || "";
          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            const data = line.slice(6).trim();
            if (data === "[DONE]") continue;
            try {
              const j = JSON.parse(data);
              const content = j.choices?.[0]?.delta?.content || "";
              if (content) send({ content });
            } catch {}
          }
        }
        send({ done: true });
      } catch (e: any) {
        send({ error: e.message });
      } finally {
        controller.close();
      }
    }
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
      "Access-Control-Allow-Origin": "*",
    },
  });
}
