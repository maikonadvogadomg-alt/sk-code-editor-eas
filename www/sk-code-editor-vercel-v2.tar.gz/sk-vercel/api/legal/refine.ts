// Vercel Edge Function — POST /api/legal/refine
export const config = { runtime: "edge" };

const SYSTEM_PROMPT = `Voce e Jamile, assistente juridica especializada em direito brasileiro.
Voce auxilia advogados na elaboracao de documentos juridicos.
REGRAS:
- Documentos juridicos: use recuo de 4cm no primeiro paragrafo
- Linguagem formal e tecnica
- Nunca invente dados, fatos, nomes, datas ou jurisprudencia
- Responda sempre em portugues brasileiro`;

const EFFORT_INSTRUCTIONS: Record<number, string> = {
  1: "ESFORCO: RAPIDO.",
  2: "ESFORCO: BASICO.",
  3: "ESFORCO: DETALHADO.",
  4: "ESFORCO: PROFUNDO.",
  5: "ESFORCO: EXAUSTIVO.",
};

const AUTO_DETECT_PROVIDERS: [string, string, string][] = [
  ["gsk_",   "https://api.groq.com/openai/v1",       "llama-3.3-70b-versatile"],
  ["sk-or-", "https://openrouter.ai/api/v1",          "openai/gpt-4o-mini"],
  ["pplx-",  "https://api.perplexity.ai",             "llama-3.1-sonar-large-128k-online"],
  ["AIza",   "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash"],
  ["xai-",   "https://api.x.ai/v1",                  "grok-3-mini"],
  ["sk-ant", "https://api.anthropic.com/v1",          "claude-3-5-haiku-20241022"],
  ["sk-",    "https://api.openai.com/v1",             "gpt-4o-mini"],
];

function detectProvider(key: string): { url: string; model: string } | null {
  for (const [prefix, url, model] of AUTO_DETECT_PROVIDERS) {
    if (key.startsWith(prefix)) return { url, model };
  }
  return null;
}

const DEMO_KEY   = process.env.OPENAI_API_KEY || "";
const DEMO_URL   = "https://api.openai.com/v1";
const DEMO_MODEL = "gpt-4o-mini";

export default async function handler(request: Request): Promise<Response> {
  if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });

  let body: any;
  try { body = await request.json(); } catch { return new Response("Invalid JSON", { status: 400 }); }

  const { messages, effortLevel, verbosity, customKey, customUrl, customModel } = body;
  if (!Array.isArray(messages) || messages.length === 0)
    return new Response(JSON.stringify({ message: "Histórico obrigatório." }), { status: 400 });

  const effort = Math.min(5, Math.max(1, Number(effortLevel) || 3));
  const verb: "curta" | "longa" = verbosity === "curta" ? "curta" : "longa";
  const base: Record<number, number> = { 1: 8192, 2: 16384, 3: 32768, 4: 65536, 5: 131072 };
  const maxTokens = verb === "curta" ? Math.min(base[effort] || 16384, 32768) : (base[effort] || 16384);

  const instr = EFFORT_INSTRUCTIONS[effort] || EFFORT_INSTRUCTIONS[3];
  const verbInstr = verb === "curta" ? "TAMANHO: CONCISO." : "TAMANHO: COMPLETO.";
  const systemContent = SYSTEM_PROMPT + "\n\n" + instr + "\n" + verbInstr;

  const cleanKey = (customKey || "").trim();
  let apiUrl: string, apiModel: string, apiKey: string, isDemo = false;

  if (cleanKey) {
    const detected = detectProvider(cleanKey);
    apiUrl   = (customUrl || detected?.url || "https://api.openai.com/v1").replace(/\/$/, "");
    apiModel = customModel || detected?.model || "gpt-4o-mini";
    apiKey   = cleanKey;
  } else {
    apiUrl = DEMO_URL; apiModel = DEMO_MODEL; apiKey = DEMO_KEY; isDemo = true;
  }

  if (!apiKey) {
    return new Response(JSON.stringify({ message: "Configure OPENAI_API_KEY no Vercel." }), { status: 503 });
  }

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (data: object) => controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
      try {
        send({ mode: isDemo ? "demo" : "custom" });
        const resp = await fetch(`${apiUrl}/chat/completions`, {
          method: "POST",
          headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            model: apiModel, max_tokens: maxTokens, temperature: 0.7, stream: true,
            messages: [{ role: "system", content: systemContent }, ...messages],
          }),
        });
        if (!resp.ok) { const err = await resp.text(); send({ error: `Erro ${resp.status}: ${err.substring(0, 200)}` }); controller.close(); return; }
        const reader = resp.body?.getReader();
        if (!reader) { send({ error: "Sem resposta." }); controller.close(); return; }
        const dec = new TextDecoder(); let buf = "";
        while (true) {
          const { done, value } = await reader.read(); if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n"); buf = lines.pop() || "";
          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            const data = line.slice(6).trim(); if (data === "[DONE]") continue;
            try { const j = JSON.parse(data); const c = j.choices?.[0]?.delta?.content || ""; if (c) send({ content: c }); } catch {}
          }
        }
        send({ done: true });
      } catch (e: any) { send({ error: e.message }); } finally { controller.close(); }
    }
  });

  return new Response(stream, {
    headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", "Connection": "keep-alive", "Access-Control-Allow-Origin": "*" },
  });
}
