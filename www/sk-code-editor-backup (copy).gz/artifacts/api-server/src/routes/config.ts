import { Router } from "express";

const router = Router();

router.get("/config", (_req, res) => {
  const devDomain = process.env["REPLIT_DEV_DOMAIN"];
  const apiPort = process.env["PORT"] ?? "8080";

  let terminalWsUrl: string | null = null;

  if (devDomain) {
    terminalWsUrl = `wss://${devDomain}:${apiPort}/api/ws/terminal`;
  }

  res.json({
    terminalWsUrl,
    apiPort,
    devDomain: devDomain ?? null,
  });
});

export default router;
