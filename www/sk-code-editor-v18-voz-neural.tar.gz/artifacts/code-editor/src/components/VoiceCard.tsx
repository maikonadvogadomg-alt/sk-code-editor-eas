import { useState, useRef, useEffect, useCallback } from "react";
import { Mic, Square, X, Loader2, Volume2 } from "lucide-react";
import { cleanForSpeech } from "@/lib/tts-service";

interface VoiceCardProps {
  onClose: () => void;
  onSend: (text: string) => Promise<string>;
}

type Phase = "idle" | "listening" | "thinking" | "speaking";

const API_BASE = (() => {
  const base = (import.meta as any).env?.BASE_URL ?? "/";
  // Remove trailing slash, then add /api
  return base.replace(/\/$/, "") + "/api";
})();

async function transcribeAudio(blob: Blob): Promise<string> {
  const arrayBuffer = await blob.arrayBuffer();
  const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
  const res = await fetch(`${API_BASE}/voice/transcribe`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ audio: base64, mimeType: blob.type || "audio/webm" }),
  });
  if (!res.ok) throw new Error("Erro na transcrição");
  const data = await res.json();
  return data.transcript ?? "";
}

async function speakText(text: string): Promise<HTMLAudioElement> {
  const res = await fetch(`${API_BASE}/voice/speak`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text, voice: "nova" }),
  });
  if (!res.ok) throw new Error("Erro na síntese de voz");
  const { audio } = await res.json();
  const src = `data:audio/mp3;base64,${audio}`;
  const el = new Audio(src);
  return el;
}

export default function VoiceCard({ onClose, onSend }: VoiceCardProps) {
  const [phase, setPhase]   = useState<Phase>("idle");
  const [heard, setHeard]   = useState("");
  const [reply, setReply]   = useState("");
  const [err, setErr]       = useState("");
  const [autoLoop, setAutoLoop] = useState(true);

  const phaseRef    = useRef<Phase>("idle");
  const recRef      = useRef<any>(null);
  const audioRef    = useRef<HTMLAudioElement | null>(null);
  const loopTimer   = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mediaRecRef = useRef<MediaRecorder | null>(null);
  const chunksRef   = useRef<Blob[]>([]);

  const setP = (p: Phase) => { phaseRef.current = p; setPhase(p); };

  const stopAll = useCallback(() => {
    recRef.current?.stop();
    mediaRecRef.current?.stop();
    if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
    if (loopTimer.current) { clearTimeout(loopTimer.current); loopTimer.current = null; }
  }, []);

  // ── Falar com voz neural ────────────────────────────────────────────────────
  const speak = useCallback(async (text: string) => {
    const clean = cleanForSpeech(text, 800);
    if (!clean.trim()) { setP("idle"); return; }
    setP("speaking");
    try {
      const audio = await speakText(clean);
      audioRef.current = audio;
      audio.onended = () => {
        audioRef.current = null;
        if (autoLoop && phaseRef.current === "speaking") {
          loopTimer.current = setTimeout(() => listen(), 600);
        } else {
          setP("idle");
        }
      };
      audio.onerror = () => { audioRef.current = null; setP("idle"); };
      audio.play().catch(() => setP("idle"));
    } catch (e: any) {
      setErr(e.message);
      setP("idle");
    }
  }, [autoLoop]);

  // ── Ouvir com Web Speech (detecta pausa automaticamente) ───────────────────
  const listen = useCallback(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      setErr("Microfone não suportado neste navegador");
      return;
    }

    setHeard("");
    setErr("");
    setP("listening");

    const rec = new SR();
    rec.lang = "pt-BR";
    rec.continuous = false;
    rec.interimResults = true;
    recRef.current = rec;

    let finalText = "";

    rec.onresult = (e: any) => {
      let interim = "";
      finalText = "";
      for (let i = 0; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) finalText += t;
        else interim += t;
      }
      setHeard(finalText || interim);
    };

    rec.onend = async () => {
      const text = finalText.trim();
      if (!text) {
        if (autoLoop && phaseRef.current === "listening") {
          loopTimer.current = setTimeout(() => listen(), 400);
        } else {
          setP("idle");
        }
        return;
      }

      setHeard(text);
      setP("thinking");

      try {
        const response = await onSend(text);
        setReply(response.slice(0, 300));
        await speak(response);
      } catch (e: any) {
        setErr(e.message);
        setP("idle");
      }
    };

    rec.onerror = (e: any) => {
      if (e.error !== "no-speech" && e.error !== "aborted") {
        setErr(`Erro: ${e.error}`);
      }
      if (autoLoop && phaseRef.current === "listening") {
        loopTimer.current = setTimeout(() => listen(), 600);
      } else {
        setP("idle");
      }
    };

    rec.start();
  }, [autoLoop, onSend, speak]);

  // Começa ouvindo ao abrir
  useEffect(() => {
    const t = setTimeout(() => listen(), 300);
    return () => {
      clearTimeout(t);
      stopAll();
    };
  }, []);

  // ── Botão principal ────────────────────────────────────────────────────────
  const handleButton = useCallback(() => {
    if (phase === "idle") {
      listen();
    } else if (phase === "listening") {
      recRef.current?.stop();
    } else if (phase === "speaking") {
      if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
      if (autoLoop) {
        loopTimer.current = setTimeout(() => listen(), 400);
      } else {
        setP("idle");
      }
    }
  }, [phase, listen, autoLoop]);

  const handleClose = useCallback(() => {
    stopAll();
    onClose();
  }, [stopAll, onClose]);

  // ── Visual por fase ────────────────────────────────────────────────────────
  const ringColor = {
    idle:     "border-gray-600",
    listening:"border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.4)]",
    thinking: "border-blue-500",
    speaking: "border-green-500 shadow-[0_0_20px_rgba(34,197,94,0.4)]",
  }[phase];

  const btnColor = {
    idle:     "bg-gray-700 hover:bg-gray-600",
    listening:"bg-red-600",
    thinking: "bg-blue-600 opacity-70",
    speaking: "bg-green-600",
  }[phase];

  const statusLabel = {
    idle:     "Toque para falar",
    listening:"Ouvindo… (para de falar para enviar)",
    thinking: "Pensando…",
    speaking: "Falando…",
  }[phase];

  const statusColor = {
    idle:     "text-gray-500",
    listening:"text-red-400",
    thinking: "text-blue-400",
    speaking: "text-green-400",
  }[phase];

  return (
    <div className="fixed bottom-16 right-3 z-50 w-72 rounded-2xl shadow-2xl border border-white/10 bg-[#141c0d]/95 backdrop-blur-md overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Volume2 size={14} className="text-green-400" />
          <span className="text-[12px] font-semibold text-green-300">Jasmim — Voz Neural</span>
          {autoLoop && (
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-green-500/15 border border-green-500/30 text-green-400 font-bold">
              AUTO
            </span>
          )}
        </div>
        <button
          onClick={handleClose}
          className="p-1 rounded-lg hover:bg-white/10 text-gray-500 hover:text-gray-300 transition-colors"
        >
          <X size={14} />
        </button>
      </div>

      {/* Corpo */}
      <div className="px-3 py-3 flex flex-col gap-2">
        {/* O que Saulo falou */}
        {heard && (
          <div className="rounded-xl bg-white/5 border border-white/10 px-3 py-2">
            <p className="text-[10px] text-gray-500 mb-0.5">Você disse:</p>
            <p className="text-[12px] text-gray-200 leading-snug">{heard}</p>
          </div>
        )}

        {/* O que Jasmim respondeu */}
        {reply && (
          <div className="rounded-xl bg-green-500/5 border border-green-500/20 px-3 py-2">
            <p className="text-[10px] text-green-600 mb-0.5">Jasmim:</p>
            <p className="text-[12px] text-green-200 leading-snug line-clamp-4">{reply}</p>
          </div>
        )}

        {/* Erro */}
        {err && (
          <p className="text-[11px] text-red-400 text-center">{err}</p>
        )}

        {/* Status */}
        <p className={`text-[11px] text-center font-medium ${statusColor}`}>{statusLabel}</p>
      </div>

      {/* Botões */}
      <div className="px-3 pb-3 flex items-center gap-2">
        {/* Botão principal */}
        <button
          onClick={handleButton}
          disabled={phase === "thinking"}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-[13px] text-white transition-all active:scale-95 disabled:opacity-40 border ${ringColor} ${btnColor}`}
        >
          {phase === "thinking" ? (
            <><Loader2 size={16} className="animate-spin" /> Pensando…</>
          ) : phase === "listening" ? (
            <><Square size={14} /> Parar</>
          ) : phase === "speaking" ? (
            <><Square size={14} /> Pular</>
          ) : (
            <><Mic size={14} /> Falar</>
          )}
        </button>

        {/* Toggle auto-loop */}
        <button
          onClick={() => setAutoLoop(v => !v)}
          title={autoLoop ? "Auto-loop ativo — clique para desativar" : "Modo manual — clique para ativar auto-loop"}
          className={`p-3 rounded-xl border text-[11px] font-bold transition-all ${
            autoLoop
              ? "bg-green-500/20 border-green-500/40 text-green-400"
              : "bg-white/5 border-white/10 text-gray-500"
          }`}
        >
          <Mic size={14} />
        </button>
      </div>
    </div>
  );
}
