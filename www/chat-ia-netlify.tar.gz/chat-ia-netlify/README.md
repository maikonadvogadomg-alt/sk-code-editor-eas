# Chat IA — Standalone para Netlify

Versão completa do Campo Livre em um único arquivo HTML.
Sem servidor, sem banco de dados.

## Como publicar no Netlify (grátis, 1 minuto)

1. Acesse https://www.netlify.com e crie uma conta gratuita
2. Na dashboard, clique em **"Add new site" → "Deploy manually"**
3. Arraste esta pasta (ou só o `index.html`) para a área indicada
4. Pronto! O site estará online em um link .netlify.app

## Funcionalidades
- Chat em tempo real com streaming
- Múltiplos provedores: Groq, OpenAI, Gemini, OpenRouter, Perplexity
- Detecção automática do provedor pela chave
- Múltiplas chaves salvas localmente
- Voz: ditar mensagens (pt-BR)
- TTS: IA lê respostas em voz alta
- Exportar conversa como .txt
- Importar arquivo de texto
- Blocos de código com botão Copiar
- Interface 100% em português

## Provedores suportados
- gsk_ → Groq (GRÁTIS, recomendado)
- sk- → OpenAI
- AIza → Google Gemini
- sk-or- → OpenRouter
- pplx- → Perplexity

## Obter chave Groq (gratuita, sem cartão)
1. Acesse https://console.groq.com
2. Crie uma conta
3. Vá em API Keys → Create API Key
4. Cole a chave (gsk_...) no campo ⚙️ do Chat IA
