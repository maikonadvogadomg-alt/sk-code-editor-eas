import { Router } from "express";
import { ReplitConnectors } from "@replit/connectors-sdk";

const router = Router();
const connectors = new ReplitConnectors();

// GET /api/github/user
router.get("/github/user", async (_req, res) => {
  try {
    const resp = await connectors.proxy("github", "/user", { method: "GET" });
    const data = await resp.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/github/repos
router.get("/github/repos", async (_req, res) => {
  try {
    const resp = await connectors.proxy("github", "/user/repos?per_page=100&sort=updated", { method: "GET" });
    const data = await resp.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/github/repos — cria repositório
router.post("/github/repos", async (req, res) => {
  const { name, description = "", isPrivate = false } = req.body;
  if (!name) return res.status(400).json({ error: "name é obrigatório" });
  try {
    const resp = await connectors.proxy("github", "/user/repos", {
      method: "POST",
      body: JSON.stringify({ name, description, private: isPrivate, auto_init: true }),
    });
    const data = await resp.json();
    res.status(resp.status).json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/github/contents/:owner/:repo?path= — navega/lista conteúdo para clone
router.get("/github/contents/:owner/:repo", async (req, res) => {
  const { owner, repo } = req.params;
  const path = (req.query.path as string) || "";
  try {
    const endpoint = path
      ? `/repos/${owner}/${repo}/contents/${path}`
      : `/repos/${owner}/${repo}/contents`;
    const resp = await connectors.proxy("github", endpoint, { method: "GET" });
    const data = await resp.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/github/push — envia/atualiza múltiplos arquivos
router.post("/github/push", async (req, res) => {
  const { owner, repo, branch = "main", files, message = "Commit via SK Code Editor" } = req.body;
  if (!owner || !repo || !files?.length) {
    return res.status(400).json({ error: "owner, repo e files são obrigatórios" });
  }
  try {
    const results: { path: string; status: string; sha?: string; error?: string }[] = [];

    for (const file of files as { path: string; content: string }[]) {
      let sha: string | undefined;
      try {
        const existing = await connectors.proxy("github", `/repos/${owner}/${repo}/contents/${file.path}?ref=${branch}`, { method: "GET" });
        if (existing.status === 200) {
          const existingData = await existing.json();
          sha = existingData.sha;
        }
      } catch { /* arquivo novo */ }

      const content = Buffer.from(file.content, "utf-8").toString("base64");
      const body: Record<string, any> = { message, content, branch };
      if (sha) body.sha = sha;

      const putResp = await connectors.proxy("github", `/repos/${owner}/${repo}/contents/${file.path}`, {
        method: "PUT",
        body: JSON.stringify(body),
      });
      const putData = await putResp.json();

      if (putResp.status === 200 || putResp.status === 201) {
        results.push({ path: file.path, status: "ok", sha: putData.content?.sha });
      } else {
        results.push({ path: file.path, status: "error", error: putData.message || "Erro" });
      }
    }

    res.json({ results });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/github/repos/:owner/:repo
router.delete("/github/repos/:owner/:repo", async (req, res) => {
  const { owner, repo } = req.params;
  try {
    const resp = await connectors.proxy("github", `/repos/${owner}/${repo}`, { method: "DELETE" });
    if (resp.status === 204) {
      res.json({ ok: true });
    } else {
      const data = await resp.json();
      res.status(resp.status).json(data);
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
