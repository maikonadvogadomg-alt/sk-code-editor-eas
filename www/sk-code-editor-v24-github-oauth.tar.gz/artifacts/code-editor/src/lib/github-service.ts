// GitHub via Replit OAuth — sem token manual, autenticação automática pelo servidor

export interface GitHubUser {
  login: string;
  name?: string;
  avatar_url?: string;
}

const BASE = "/api/github";

export async function getGitHubUser(): Promise<GitHubUser> {
  const res = await fetch(`${BASE}/user`);
  if (!res.ok) throw new Error(`Não foi possível autenticar: ${res.status}`);
  return res.json();
}

export async function listRepos(): Promise<any[]> {
  const res = await fetch(`${BASE}/repos`);
  if (!res.ok) throw new Error(`Erro ao listar repos: ${res.status}`);
  return res.json();
}

export async function createRepo(
  name: string,
  description: string = "",
  isPrivate: boolean = false
): Promise<any> {
  const res = await fetch(`${BASE}/repos`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, description, isPrivate }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || data.error || `Erro ${res.status}`);
  return data;
}

export async function pushAllFiles(
  owner: string,
  repo: string,
  files: Record<string, string>,
  commitMessage: string
): Promise<{ success: number; failed: number; errors: string[] }> {
  const fileList = Object.entries(files).map(([path, content]) => ({ path, content }));

  const res = await fetch(`${BASE}/push`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ owner, repo, files: fileList, message: commitMessage }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `Erro ${res.status}`);
  }

  const data = await res.json();
  const results: { path: string; status: string; error?: string }[] = data.results ?? [];
  const success = results.filter(r => r.status === "ok").length;
  const errors = results.filter(r => r.status !== "ok").map(r => `${r.path}: ${r.error}`);
  return { success, failed: errors.length, errors };
}

// Clone — navega recursivamente pela API do servidor
export async function cloneRepo(
  owner: string,
  repo: string
): Promise<Record<string, string>> {
  const files: Record<string, string> = {};

  async function fetchDir(path: string) {
    const url = `${BASE}/contents/${owner}/${repo}${path ? `?path=${encodeURIComponent(path)}` : ""}`;
    const res = await fetch(url);
    if (!res.ok) return;
    const contents = await res.json();
    if (!Array.isArray(contents)) return;

    for (const item of contents) {
      if (item.type === "file" && item.size < 500_000) {
        try {
          const fileRes = await fetch(
            `${BASE}/contents/${owner}/${repo}?path=${encodeURIComponent(item.path)}`
          );
          if (!fileRes.ok) continue;
          const fileData = await fileRes.json();
          if (fileData.content) {
            files[item.path] = atob(fileData.content.replace(/\n/g, ""));
          } else if (fileData.download_url) {
            const raw = await fetch(fileData.download_url);
            if (raw.ok) files[item.path] = await raw.text();
          }
        } catch { /* ignora erros individuais */ }
      } else if (item.type === "dir") {
        await fetchDir(item.path);
      }
    }
  }

  await fetchDir("");
  return files;
}
