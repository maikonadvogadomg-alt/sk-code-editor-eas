import { useState, useCallback, useEffect } from "react";
import {
  GitBranch, Upload, Plus, Loader2, ExternalLink,
  Lock, Unlock, CheckCircle2, ChevronRight,
  RefreshCw, Download, X, AlertCircle,
} from "lucide-react";
import {
  GitHubUser,
  getGitHubUser,
  listRepos,
  cloneRepo,
  pushAllFiles,
  createRepo,
} from "@/lib/github-service";

interface GitHubPanelProps {
  files: Record<string, string>;
  onImport: (files: Record<string, string>) => void;
  projectName: string;
}

type View = "home" | "push-new" | "push-existing" | "clone";

export default function GitHubPanel({ files, onImport, projectName }: GitHubPanelProps) {
  const [user, setUser]       = useState<GitHubUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState("");
  const [view, setView]       = useState<View>("home");

  // Carrega usuário autenticado via OAuth do Replit
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const u = await getGitHubUser();
        if (!cancelled) setUser(u);
      } catch (e: any) {
        if (!cancelled) setError(e.message || "Erro ao autenticar com GitHub");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center gap-3 text-gray-500">
        <Loader2 size={22} className="animate-spin text-green-500" />
        <p className="text-sm">Conectando ao GitHub...</p>
      </div>
    );
  }

  if (error || !user) {
    return (
      <div className="h-full flex flex-col items-center justify-center gap-4 px-6 text-center">
        <AlertCircle size={28} className="text-red-400" />
        <div>
          <p className="text-sm font-bold text-gray-300 mb-1">Não foi possível conectar</p>
          <p className="text-xs text-gray-600 leading-relaxed">{error || "Conta GitHub não autorizada."}</p>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-green-600/20 border border-green-600/30 rounded-xl text-xs text-green-400 font-semibold hover:bg-green-600/30 transition-colors"
        >
          Tentar novamente
        </button>
      </div>
    );
  }

  return (
    <PanelMain
      user={user}
      files={files}
      projectName={projectName}
      onImport={onImport}
      view={view}
      setView={setView}
    />
  );
}

// ── Painel principal ────────────────────────────────────────────────────────
function PanelMain({
  user, files, projectName, onImport, view, setView,
}: {
  user: GitHubUser;
  files: Record<string, string>;
  projectName: string;
  onImport: (files: Record<string, string>) => void;
  view: View;
  setView: (v: View) => void;
}) {
  const [repos, setRepos]           = useState<any[]>([]);
  const [reposLoaded, setReposLoaded] = useState(false);
  const [loading, setLoading]       = useState(false);
  const [status, setStatus]         = useState<{ msg: string; ok?: boolean; url?: string } | null>(null);

  const [newName, setNewName]       = useState(
    projectName.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "")
  );
  const [newDesc, setNewDesc]       = useState("");
  const [newPrivate, setNewPrivate] = useState(false);
  const [commitMsg, setCommitMsg]   = useState(
    `Enviado pelo SK Code Editor — ${new Date().toLocaleDateString("pt-BR")}`
  );
  const [selectedRepo, setSelectedRepo] = useState<any>(null);

  const fileCount = Object.keys(files).length;

  const loadRepos = useCallback(async () => {
    setLoading(true);
    try {
      const list = await listRepos();
      setRepos(list);
      setReposLoaded(true);
    } catch (e: any) {
      setStatus({ msg: `Erro ao buscar repositórios: ${e.message}` });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if ((view === "push-existing" || view === "clone") && !reposLoaded) loadRepos();
  }, [view, reposLoaded, loadRepos]);

  const handlePushNew = async () => {
    if (!newName.trim()) return;
    setLoading(true);
    setStatus({ msg: "Criando repositório..." });
    try {
      const created = await createRepo(newName.trim(), newDesc, newPrivate);
      setStatus({ msg: "Enviando arquivos..." });
      const result = await pushAllFiles(user.login, newName.trim(), files, commitMsg);
      setStatus({
        msg: `✓ ${result.success} arquivo(s) enviados para "${newName}"`,
        ok: true,
        url: created.html_url,
      });
    } catch (e: any) {
      setStatus({ msg: `Erro: ${e.message}` });
    } finally {
      setLoading(false);
    }
  };

  const handlePushExisting = async () => {
    if (!selectedRepo) return;
    setLoading(true);
    setStatus({ msg: `Enviando para ${selectedRepo.full_name}...` });
    try {
      const result = await pushAllFiles(selectedRepo.owner.login, selectedRepo.name, files, commitMsg);
      setStatus({
        msg: `✓ ${result.success} arquivo(s) atualizados em "${selectedRepo.full_name}"`,
        ok: true,
        url: selectedRepo.html_url,
      });
    } catch (e: any) {
      setStatus({ msg: `Erro: ${e.message}` });
    } finally {
      setLoading(false);
    }
  };

  const handleClone = async (repo: any) => {
    setLoading(true);
    setStatus({ msg: `Baixando ${repo.full_name}...` });
    try {
      const imported = await cloneRepo(repo.owner.login, repo.name);
      onImport(imported);
      setStatus({ msg: `✓ ${Object.keys(imported).length} arquivos importados de "${repo.name}"`, ok: true });
    } catch (e: any) {
      setStatus({ msg: `Erro: ${e.message}` });
    } finally {
      setLoading(false);
    }
  };

  const goHome = () => { setView("home"); setStatus(null); setSelectedRepo(null); };

  // ── STATUS BANNER ──────────────────────────────────────────────────────
  const StatusBanner = () => status ? (
    <div className={`mx-4 mb-3 px-3 py-2.5 rounded-xl border text-[12px] flex items-start gap-2 ${
      status.ok ? "bg-green-500/10 border-green-500/20 text-green-400" : "bg-red-500/10 border-red-500/20 text-red-400"
    }`}>
      {status.ok ? <CheckCircle2 size={13} className="shrink-0 mt-0.5" /> : <AlertCircle size={13} className="shrink-0 mt-0.5" />}
      <div className="flex-1 min-w-0">
        <span className="leading-relaxed">{status.msg}</span>
        {status.url && (
          <a
            href={status.url} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-1 mt-1 text-green-300 hover:underline text-[11px]"
          >
            <ExternalLink size={10} /> Abrir no GitHub →
          </a>
        )}
      </div>
    </div>
  ) : null;

  // ── HOME ────────────────────────────────────────────────────────────────
  if (view === "home") return (
    <div className="h-full flex flex-col">
      {/* User badge */}
      <div className="flex items-center gap-2 px-4 py-3 bg-[#1c2714] border-b border-gray-700/30">
        <CheckCircle2 size={14} className="text-green-400" />
        <span className="text-xs font-semibold text-gray-300">@{user.login}</span>
        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-green-900/30 text-green-500 border border-green-700/30 ml-1">OAuth ✓</span>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {/* Projeto atual */}
        <div className="px-3 py-2.5 bg-[#1c2714] border border-gray-700/30 rounded-xl">
          <p className="text-[10px] text-gray-600 uppercase tracking-wider font-semibold mb-0.5">Projeto atual</p>
          <p className="text-sm font-bold text-white truncate">{projectName}</p>
          <p className="text-[11px] text-gray-500">{fileCount} arquivo{fileCount !== 1 ? "s" : ""}</p>
        </div>

        {/* Enviar */}
        <div>
          <p className="text-[10px] text-gray-600 uppercase tracking-wider font-semibold mb-2 px-1">Enviar para GitHub</p>
          <button
            onClick={() => setView("push-new")}
            className="w-full flex items-center gap-3 px-4 py-3.5 bg-green-600/10 border border-green-500/30 rounded-xl hover:bg-green-600/15 transition-colors text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-green-500/15 flex items-center justify-center shrink-0">
              <Plus size={17} className="text-green-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-bold text-green-400">Criar repositório novo e enviar</p>
              <p className="text-[11px] text-gray-500 mt-0.5">Cria um repo novo e sobe todos os arquivos</p>
            </div>
            <ChevronRight size={15} className="text-gray-600 shrink-0" />
          </button>

          <button
            onClick={() => setView("push-existing")}
            className="w-full flex items-center gap-3 px-4 py-3 mt-2 bg-[#1c2714] border border-gray-700/40 rounded-xl hover:border-gray-600/50 transition-colors text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center shrink-0">
              <Upload size={16} className="text-blue-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-semibold text-gray-200">Enviar para repo existente</p>
              <p className="text-[11px] text-gray-500 mt-0.5">Atualiza um repositório que já existe</p>
            </div>
            <ChevronRight size={15} className="text-gray-600 shrink-0" />
          </button>
        </div>

        {/* Importar */}
        <div>
          <p className="text-[10px] text-gray-600 uppercase tracking-wider font-semibold mb-2 px-1">Baixar do GitHub</p>
          <button
            onClick={() => setView("clone")}
            className="w-full flex items-center gap-3 px-4 py-3 bg-[#1c2714] border border-gray-700/40 rounded-xl hover:border-gray-600/50 transition-colors text-left"
          >
            <div className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center shrink-0">
              <Download size={16} className="text-purple-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-semibold text-gray-200">Importar repositório</p>
              <p className="text-[11px] text-gray-500 mt-0.5">Baixa um repositório para editar aqui</p>
            </div>
            <ChevronRight size={15} className="text-gray-600 shrink-0" />
          </button>
        </div>
      </div>

      <StatusBanner />
    </div>
  );

  // ── PUSH REPO NOVO ──────────────────────────────────────────────────────
  if (view === "push-new") return (
    <div className="h-full flex flex-col">
      <div className="flex items-center gap-2 px-4 py-3 bg-[#1c2714] border-b border-gray-700/30">
        <button onClick={goHome} className="p-1 rounded-lg hover:bg-white/10 text-gray-500"><X size={15} /></button>
        <span className="text-sm font-bold text-white">Criar repositório e enviar</span>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        <div className="space-y-1.5">
          <label className="text-[11px] text-gray-500 uppercase tracking-wider font-semibold">Nome do Repositório</label>
          <input
            value={newName}
            onChange={e => setNewName(e.target.value.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, ""))}
            placeholder="meu-projeto"
            className="w-full px-3 py-2.5 bg-[#1c2714] border border-gray-700/50 rounded-xl text-sm text-gray-300 placeholder-gray-700 outline-none focus:border-green-500/50"
          />
          <p className="text-[10px] text-gray-600">
            github.com/{user.login}/{newName || "..."}
          </p>
        </div>
        <div className="space-y-1.5">
          <label className="text-[11px] text-gray-500 uppercase tracking-wider font-semibold">Descrição (opcional)</label>
          <input
            value={newDesc}
            onChange={e => setNewDesc(e.target.value)}
            placeholder="Descrição do projeto..."
            className="w-full px-3 py-2.5 bg-[#1c2714] border border-gray-700/50 rounded-xl text-sm text-gray-300 placeholder-gray-700 outline-none focus:border-green-500/50"
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-[11px] text-gray-500 uppercase tracking-wider font-semibold">Mensagem do commit</label>
          <input
            value={commitMsg}
            onChange={e => setCommitMsg(e.target.value)}
            className="w-full px-3 py-2.5 bg-[#1c2714] border border-gray-700/50 rounded-xl text-sm text-gray-300 outline-none focus:border-green-500/50"
          />
        </div>
        <button
          onClick={() => setNewPrivate(!newPrivate)}
          className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl border w-full text-left transition-colors ${
            newPrivate ? "bg-yellow-500/10 border-yellow-500/30" : "bg-[#1c2714] border-gray-700/40"
          }`}
        >
          {newPrivate ? <Lock size={15} className="text-yellow-400" /> : <Unlock size={15} className="text-green-400" />}
          <div>
            <p className="text-[13px] font-semibold text-gray-200">{newPrivate ? "Privado" : "Público"}</p>
            <p className="text-[11px] text-gray-500">{newPrivate ? "Só você vê" : "Qualquer pessoa pode ver"}</p>
          </div>
        </button>

        {status && (
          <div className={`px-3 py-2.5 rounded-xl border text-[12px] flex items-start gap-2 ${
            status.ok ? "bg-green-500/10 border-green-500/20 text-green-400" : "bg-red-500/10 border-red-500/20 text-red-400"
          }`}>
            {status.ok ? <CheckCircle2 size={13} className="shrink-0 mt-0.5" /> : <AlertCircle size={13} className="shrink-0 mt-0.5" />}
            <div>
              <span>{status.msg}</span>
              {status.url && (
                <a href={status.url} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-1 mt-1 text-green-300 hover:underline text-[11px]">
                  <ExternalLink size={10} /> Abrir no GitHub →
                </a>
              )}
            </div>
          </div>
        )}

        <p className="text-[11px] text-gray-600 px-1">{fileCount} arquivo{fileCount !== 1 ? "s" : ""} serão enviados</p>
      </div>
      <div className="px-4 pb-5 pt-2">
        <button
          onClick={handlePushNew}
          disabled={!newName.trim() || loading}
          className="w-full flex items-center justify-center gap-2 py-3.5 bg-green-600 disabled:opacity-40 text-white rounded-xl font-bold text-[15px] hover:bg-green-500 transition-colors"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
          {loading ? "Enviando..." : "Criar e Enviar"}
        </button>
      </div>
    </div>
  );

  // ── PUSH REPO EXISTENTE ─────────────────────────────────────────────────
  if (view === "push-existing") return (
    <div className="h-full flex flex-col">
      <div className="flex items-center gap-2 px-4 py-3 bg-[#1c2714] border-b border-gray-700/30">
        <button onClick={goHome} className="p-1 rounded-lg hover:bg-white/10 text-gray-500"><X size={15} /></button>
        <span className="text-sm font-bold text-white">Enviar para repositório</span>
        <button onClick={loadRepos} disabled={loading} className="ml-auto p-1 rounded-lg hover:bg-white/10 text-gray-500">
          <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {!reposLoaded && loading && (
          <div className="flex items-center justify-center py-12 gap-2 text-gray-500 text-sm">
            <Loader2 size={16} className="animate-spin" /> Buscando repositórios...
          </div>
        )}
        {reposLoaded && (
          <div className="px-4 py-3 space-y-2">
            {selectedRepo && (
              <div className="space-y-2 pb-2 border-b border-gray-800/50">
                <div className="flex items-center gap-2 px-3 py-2 bg-green-500/10 border border-green-500/20 rounded-xl">
                  <CheckCircle2 size={14} className="text-green-400 shrink-0" />
                  <span className="text-[12px] text-green-400 font-semibold truncate">{selectedRepo.full_name}</span>
                  <button onClick={() => setSelectedRepo(null)} className="ml-auto text-gray-600 hover:text-gray-400 shrink-0"><X size={13} /></button>
                </div>
                <label className="text-[11px] text-gray-500 uppercase tracking-wider font-semibold block">Mensagem do commit</label>
                <input
                  value={commitMsg}
                  onChange={e => setCommitMsg(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#1c2714] border border-gray-700/50 rounded-xl text-sm text-gray-300 outline-none focus:border-green-500/50"
                />
                {status && (
                  <div className={`px-3 py-2.5 rounded-xl border text-[12px] flex items-start gap-2 ${
                    status.ok ? "bg-green-500/10 border-green-500/20 text-green-400" : "bg-red-500/10 border-red-500/20 text-red-400"
                  }`}>
                    {status.ok ? <CheckCircle2 size={13} className="shrink-0 mt-0.5" /> : <AlertCircle size={13} className="shrink-0 mt-0.5" />}
                    <div>
                      <span>{status.msg}</span>
                      {status.url && (
                        <a href={status.url} target="_blank" rel="noopener noreferrer"
                          className="flex items-center gap-1 mt-1 text-green-300 hover:underline text-[11px]">
                          <ExternalLink size={10} /> Abrir no GitHub →
                        </a>
                      )}
                    </div>
                  </div>
                )}
                <button
                  onClick={handlePushExisting}
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-green-600 disabled:opacity-40 text-white rounded-xl font-bold text-[14px] hover:bg-green-500 transition-colors"
                >
                  {loading ? <Loader2 size={15} className="animate-spin" /> : <Upload size={15} />}
                  {loading ? "Enviando..." : `Enviar ${fileCount} arquivo(s)`}
                </button>
              </div>
            )}
            {!selectedRepo && <p className="text-[11px] text-gray-600 pb-1">Escolha o repositório de destino:</p>}
            {repos.map(repo => (
              <button
                key={repo.id}
                onClick={() => setSelectedRepo(repo)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border text-left transition-colors ${
                  selectedRepo?.id === repo.id ? "bg-green-500/10 border-green-500/30" : "bg-[#1c2714] border-gray-700/30 hover:border-gray-600/50"
                }`}
              >
                {repo.private ? <Lock size={12} className="text-yellow-500 shrink-0" /> : <Unlock size={12} className="text-gray-600 shrink-0" />}
                <div className="flex-1 min-w-0">
                  <p className="text-[12px] font-semibold text-gray-300 truncate">{repo.full_name}</p>
                  {repo.description && <p className="text-[10px] text-gray-600 truncate">{repo.description}</p>}
                </div>
                {selectedRepo?.id === repo.id && <CheckCircle2 size={14} className="text-green-400 shrink-0" />}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  // ── CLONE ───────────────────────────────────────────────────────────────
  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center gap-2 px-4 py-3 bg-[#1c2714] border-b border-gray-700/30">
        <button onClick={goHome} className="p-1 rounded-lg hover:bg-white/10 text-gray-500"><X size={15} /></button>
        <span className="text-sm font-bold text-white">Importar repositório</span>
        <button onClick={loadRepos} disabled={loading} className="ml-auto p-1 rounded-lg hover:bg-white/10 text-gray-500">
          <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {!reposLoaded && loading && (
          <div className="flex items-center justify-center py-12 gap-2 text-gray-500 text-sm">
            <Loader2 size={16} className="animate-spin" /> Buscando repositórios...
          </div>
        )}
        {reposLoaded && (
          <div className="px-4 py-3 space-y-2">
            {status && (
              <div className={`px-3 py-2.5 rounded-xl border text-[12px] flex items-start gap-2 mb-2 ${
                status.ok ? "bg-green-500/10 border-green-500/20 text-green-400" : "bg-red-500/10 border-red-500/20 text-red-400"
              }`}>
                {status.ok ? <CheckCircle2 size={13} className="shrink-0 mt-0.5" /> : <AlertCircle size={13} className="shrink-0 mt-0.5" />}
                <span>{status.msg}</span>
              </div>
            )}
            <p className="text-[11px] text-gray-600 pb-1">Clique em um repositório para importar:</p>
            {repos.map(repo => (
              <button
                key={repo.id}
                onClick={() => handleClone(repo)}
                disabled={loading}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border bg-[#1c2714] border-gray-700/30 hover:border-green-600/40 hover:bg-green-900/10 text-left transition-colors disabled:opacity-40"
              >
                {repo.private ? <Lock size={12} className="text-yellow-500 shrink-0" /> : <Unlock size={12} className="text-gray-600 shrink-0" />}
                <div className="flex-1 min-w-0">
                  <p className="text-[12px] font-semibold text-gray-300 truncate">{repo.full_name}</p>
                  {repo.description && <p className="text-[10px] text-gray-600 truncate">{repo.description}</p>}
                </div>
                <Download size={13} className="text-gray-600 shrink-0" />
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
