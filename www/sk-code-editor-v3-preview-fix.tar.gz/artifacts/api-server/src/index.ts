import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn, spawnSync } from "node:child_process";
import { existsSync, chmodSync } from "node:fs";
import http from "http";
import { WebSocketServer, WebSocket } from "ws";
import app from "./app";
import { logger } from "./lib/logger";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const rawPort = process.env["PORT"];
if (!rawPort) throw new Error("PORT environment variable is required.");
const port = Number(rawPort);
if (Number.isNaN(port) || port <= 0) throw new Error(`Invalid PORT: "${rawPort}"`);

const server = http.createServer(app);

// ─── WebSocket Terminal ───────────────────────────────────────────────────────
const wss = new WebSocketServer({ noServer: true });

server.on("upgrade", (req, socket, head) => {
  const url = req.url ?? "";
  if (url === "/api/ws/terminal" || url === "/ws/terminal" || url.endsWith("/ws/terminal")) {
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit("connection", ws, req));
  } else {
    socket.destroy();
  }
});

// ─── Compilar pty_helper em tempo de execução se necessário ──────────────────
// Em produção o build não roda, então compilamos aqui na primeira vez.
const PTY_HELPER = path.resolve(__dirname, "../pty_helper");
const PTY_SRC    = path.resolve(__dirname, "../pty_helper.c");

function compilePtyHelper(): boolean {
  if (!existsSync(PTY_SRC)) {
    logger.warn("pty_helper.c nao encontrado — PTY indisponivel");
    return false;
  }
  const compilers = ["gcc", "cc", "g++"];
  for (const cc of compilers) {
    const r = spawnSync(cc, ["-O2", "-o", PTY_HELPER, PTY_SRC, "-lutil"], {
      stdio: "pipe",
      encoding: "utf8",
    });
    if (r.status === 0) {
      try { chmodSync(PTY_HELPER, 0o755); } catch { /* ok */ }
      logger.info(`pty_helper compilado em runtime com ${cc}`);
      return true;
    }
  }
  logger.warn("nao foi possivel compilar pty_helper — gcc/cc nao encontrado");
  return false;
}

let USE_PTY = existsSync(PTY_HELPER);
if (!USE_PTY) {
  logger.warn("pty_helper nao encontrado — tentando compilar agora...");
  USE_PTY = compilePtyHelper();
}
if (!USE_PTY) {
  logger.warn("pty_helper indisponivel — terminal rodando em modo bash direto (sem cores/resize)");
}

// Usa /home/runner como CWD para evitar conflitos com o monorepo pnpm na raiz do workspace
const cwd =
  process.env["HOME"] ||
  process.env["REPL_HOME"] ||
  "/home/runner";

const shellEnv = {
  ...process.env,
  TERM: "xterm-256color",
  COLORTERM: "truecolor",
  FORCE_COLOR: "3",
  LANG: "pt_BR.UTF-8",
  SHELL: process.env["SHELL"] || "/bin/bash",
};

wss.on("connection", (ws: WebSocket) => {
  let cols = 220;
  let rows = 50;

  // Inicia processo de terminal (PTY helper ou bash direto)
  const shell = USE_PTY
    ? spawn(PTY_HELPER, [String(rows), String(cols)], { cwd, env: shellEnv, stdio: ["pipe", "pipe", "pipe"] })
    : spawn("/bin/bash", ["--login"], { cwd, env: shellEnv, stdio: ["pipe", "pipe", "pipe"] });

  shell.on("error", (err) => {
    logger.error({ err }, "Erro ao iniciar shell");
    const msg = `\r\n\x1b[31m[Erro ao iniciar terminal: ${err.message}]\x1b[0m\r\n`;
    if (ws.readyState === WebSocket.OPEN) ws.send(Buffer.from(msg));
    ws.close();
  });

  const send = (data: Buffer | string) => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(data instanceof Buffer ? data : Buffer.from(data));
    }
  };

  shell.stdout?.on("data", (chunk: Buffer) => send(chunk));
  shell.stderr?.on("data", (chunk: Buffer) => send(chunk));

  shell.on("exit", (code: number | null) => {
    send(`\r\n\x1b[90m[processo encerrado com código ${code ?? 0}]\x1b[0m\r\n`);
    try { ws.close(); } catch { }
  });

  ws.on("message", (data: Buffer | string) => {
    try {
      const msg = typeof data === "string" ? data : data.toString();

      // Resize: {"type":"resize","cols":N,"rows":N}
      if (msg.startsWith("{") && msg.includes('"type":"resize"')) {
        try {
          const obj = JSON.parse(msg);
          if (obj.type === "resize" && obj.cols && obj.rows) {
            cols = obj.cols;
            rows = obj.rows;
            if (USE_PTY) {
              const resizeCmd = Buffer.concat([
                Buffer.from([0x00]),
                Buffer.from(`RESIZE:${rows}:${cols}\n`),
              ]);
              shell.stdin?.write(resizeCmd);
            }
          }
        } catch { }
        return;
      }

      shell.stdin?.write(typeof data === "string" ? data : data);
    } catch (err) {
      logger.warn({ err }, "Erro ao escrever no shell");
    }
  });

  ws.on("close", () => { try { shell.kill("SIGTERM"); } catch { } });
  ws.on("error", () => { try { shell.kill("SIGTERM"); } catch { } });
});

// ─── HTTP Listen ──────────────────────────────────────────────────────────────
server.listen(port, (err?: Error) => {
  if (err) { logger.error({ err }, "Error listening"); process.exit(1); }
  logger.info({ port, pty: USE_PTY }, "Server listening");
});
