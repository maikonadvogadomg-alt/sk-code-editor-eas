import { useState, useRef, useEffect, useCallback } from "react";
import { Mic, Square, X, Loader2, Volume2, Settings2, ChevronDown, ChevronUp } from "lucide-react";
import { cleanForSpeech } from "@/lib/tts-service";

interface VoiceCardProps {
  onClose: () => void;
  onSend: (text: string) => Promise<string>;
}

type Phase = "idle" | "listening" | "thinking" | "speaking";

// ── Vozes disponíveis (OpenAI gpt-audio) ──────────────────────────────────
const VOICES = [
  { id: "nova",    label: "Nova",    desc: "Calorosa e conversacional" },
  { id: "alloy",   label: "Alloy",   desc: "Neutra e profissional" },
  { id: "echo",    label: "Echo",    desc: "Clara e grave" },
  { id: "fable",   label: "Fable",   desc: "Narrativa e expressiva" },
  { id: "onyx",    label: "Onyx",    desc: "Grave e marcante" },
  { id: "shimmer", label: "Shimmer", desc: "Leve e alegre" },
];

const SPEEDS = [
  { id: "devagar",    label: "🐢 Devagar",    prompt: "Fale bem devagar e claramente." },
  { id: "normal",     label: "🎯 Normal",     prompt: "Fale em velocidade normal." },
  { id: "rapido",     label: "🚀 Rápido",     prompt: "Fale um pouco mais rápido que o normal." },
  { id: "muito-rapido", label: "⚡ Muito rápido", prompt: "Fale rapidamente, mas mantendo clareza." },
];

const STYLES = [
  { id: "curto",     label: "📝 Curto",     prompt: "Responda de forma muito breve, máximo 2 frases." },
  { id: "normal",    label: "💬 Normal",    prompt: "Responda de forma conversacional, 2-3 frases." },
  { id: "detalhado", label: "📖 Detalhado", prompt: "Pode dar respostas mais completas quando necessário." },
];

const STORAGE_KEY = "voice-card-config";

interface VoiceConfig {
  voice: string;
  speed: string;
  style: string;
  autoLoop: boolean;
}

function loadConfig(): VoiceConfig {
  try {
    const s = localStorage.getItem(STORAGE_KEY);
    if (s) return { ...{ voice: "nova", speed: "normal", style: "normal", autoLoop: true }, ...JSON.parse(s) };
  } catch {}
  return { voice: "nova", speed: "normal", style: "normal", autoLoop: true };
}

function saveConfig(c: VoiceConfig) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(c)); } catch {}
}

const API_BASE = (() => {
  const base = (import.meta as any).env?.BASE_URL ?? "/";
  return base.replace(/\/$/, "") + "/api";
})();

async function speakText(text: string, voice: string, speedPrompt: string): Promise<HTMLAudioElement> {
  const res = await fetch(`${API_BASE}/voice/speak`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text, voice, speedPrompt }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error ?? "Erro na síntese de voz");
  }
  const { audio } = await res.json();
  return new Audio(`data:audio/mp3;base64,${audio}`);
}

export default function VoiceCard({ onClose, onSend }: VoiceCardProps) {
  const [cfg, setCfg]       = useState<VoiceConfig>(loadConfig);
  const [phase, setPhase]   = useState<Phase>("idle");
  const [heard, setHeard]   = useState("");
  const [reply, setReply]   = useState("");
  const [err, setErr]       = useState("");
  const [showSettings, setShowSettings] = useState(false);

  const phaseRef   = useRef<Phase>("idle");
  const recRef     = useRef<any>(null);
  const audioRef   = useRef<HTMLAudioElement | null>(null);
  const loopTimer  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cfgRef     = useRef<VoiceConfig>(cfg);

  // Mantém cfgRef em sync sem recriar callbacks
  useEffect(() => { cfgRef.current = cfg; saveConfig(cfg); }, [cfg]);

  const setP = (p: Phase) => { phaseRef.current = p; setPhase(p); };

  const stopAll = useCallback(() => {
    recRef.current?.abort?.();
    recRef.current?.stop?.();
    if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
    if (loopTimer.current) { clearTimeout(loopTimer.current); loopTimer.current = null; }
  }, []);

  // ── Falar com voz neural ──────────────────────────────────────────────────
  const speak = useCallback(async (text: string) => {
    const clean = cleanForSpeech(text, 900);
    if (!clean.trim()) { setP("idle"); return; }
    setP("speaking");

    const { voice, speed } = cfgRef.current;
    const speedObj = SPEEDS.find(s => s.id === speed) ?? SPEEDS[1];

    try {
      const audio = await speakText(clean, voice, speedObj.prompt);
      audioRef.current = audio;
      audio.onended = () => {
        audioRef.current = null;
        if (cfgRef.current.autoLoop && phaseRef.current === "speaking") {
          loopTimer.current = setTimeout(listen, 600);
        } else {
          setP("idle");
        }
      };
      audio.onerror = () => { audioRef.current = null; setP("idle"); };
      audio.play().catch(() => setP("idle"));
    } catch (e: any) {
      setErr(e.message);
      setP("idle");
    }
  }, []);

  // ── Ouvir com Web Speech API ──────────────────────────────────────────────
  const listen = useCallback(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { setErr("Microfone não suportado neste navegador"); return; }

    setHeard(""); setErr(""); setP("listening");

    const rec = new SR();
    rec.lang = "pt-BR";
    rec.continuous = false;
    rec.interimResults = true;
    recRef.current = rec;
    let finalText = "";

    rec.onresult = (e: any) => {
      let interim = "";
      finalText = "";
      for (let i = 0; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) finalText += t; else interim += t;
      }
      setHeard(finalText || interim);
    };

    rec.onend = async () => {
      const text = finalText.trim();
      if (!text) {
        if (cfgRef.current.autoLoop && phaseRef.current === "listening") {
          loopTimer.current = setTimeout(listen, 400);
        } else setP("idle");
        return;
      }
      setHeard(text);
      setP("thinking");
      try {
        // Injeta instrução de estilo na mensagem (transparente para o usuário)
        const styleObj = STYLES.find(s => s.id === cfgRef.current.style) ?? STYLES[1];
        const enriched = `[${styleObj.prompt}] ${text}`;
        const response = await onSend(enriched);
        setReply(response.slice(0, 400));
        await speak(response);
      } catch (e: any) {
        setErr(e.message);
        setP("idle");
      }
    };

    rec.onerror = (e: any) => {
      if (e.error !== "no-speech" && e.error !== "aborted") setErr(`Erro: ${e.error}`);
      if (cfgRef.current.autoLoop && phaseRef.current === "listening") {
        loopTimer.current = setTimeout(listen, 600);
      } else setP("idle");
    };

    rec.start();
  }, [onSend, speak]);

  useEffect(() => {
    const t = setTimeout(listen, 300);
    return () => { clearTimeout(t); stopAll(); };
  }, []);

  const handleButton = useCallback(() => {
    if (phase === "idle") listen();
    else if (phase === "listening") recRef.current?.stop();
    else if (phase === "speaking") {
      if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
      if (cfgRef.current.autoLoop) loopTimer.current = setTimeout(listen, 400);
      else setP("idle");
    }
  }, [phase, listen]);

  const handleClose = useCallback(() => { stopAll(); onClose(); }, [stopAll, onClose]);

  const update = (patch: Partial<VoiceConfig>) => setCfg(prev => ({ ...prev, ...patch }));

  // ── Cores por fase ────────────────────────────────────────────────────────
  const btnColor = {
    idle:     "bg-gray-700 hover:bg-gray-600 border-gray-600",
    listening:"bg-red-600 border-red-500 shadow-[0_0_16px_rgba(239,68,68,0.35)]",
    thinking: "bg-blue-600 border-blue-500 opacity-70",
    speaking: "bg-green-600 border-green-500 shadow-[0_0_16px_rgba(34,197,94,0.35)]",
  }[phase];

  const statusLabel = {
    idle:     "Toque para falar",
    listening:"Ouvindo… (pare de falar para enviar)",
    thinking: "Pensando…",
    speaking: "Falando…",
  }[phase];

  const statusColor = {
    idle:"text-gray-500", listening:"text-red-400", thinking:"text-blue-400", speaking:"text-green-400",
  }[phase];

  return (
    <div className="fixed bottom-16 right-3 z-50 w-72 rounded-2xl shadow-2xl border border-white/10 bg-[#141c0d]/97 backdrop-blur-md overflow-hidden">

      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Volume2 size={13} className="text-green-400" />
          <span className="text-[12px] font-semibold text-green-300">Jasmim — Voz Neural</span>
          {cfg.autoLoop && (
            <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-green-500/15 border border-green-500/30 text-green-400 font-bold">AUTO</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setShowSettings(v => !v)}
            title="Configurações de voz"
            className={`p-1.5 rounded-lg transition-colors ${showSettings ? "bg-white/10 text-white" : "hover:bg-white/10 text-gray-500 hover:text-gray-300"}`}
          >
            <Settings2 size={13} />
          </button>
          <button onClick={handleClose} className="p-1.5 rounded-lg hover:bg-white/10 text-gray-500 hover:text-gray-300 transition-colors">
            <X size={13} />
          </button>
        </div>
      </div>

      {/* Painel de configurações */}
      {showSettings && (
        <div className="px-3 py-3 border-b border-white/10 bg-white/3 flex flex-col gap-3">

          {/* Voz */}
          <div>
            <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider mb-1.5">🎤 Voz</p>
            <div className="grid grid-cols-3 gap-1">
              {VOICES.map(v => (
                <button
                  key={v.id}
                  onClick={() => update({ voice: v.id })}
                  className={`px-2 py-1.5 rounded-lg text-[10px] font-semibold text-center transition-all ${
                    cfg.voice === v.id
                      ? "bg-green-500/25 border border-green-500/50 text-green-300"
                      : "bg-white/5 border border-white/10 text-gray-400 hover:bg-white/10"
                  }`}
                  title={v.desc}
                >
                  {v.label}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-gray-600 mt-1 text-center italic">
              {VOICES.find(v => v.id === cfg.voice)?.desc}
            </p>
          </div>

          {/* Velocidade */}
          <div>
            <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider mb-1.5">⚡ Velocidade</p>
            <div className="grid grid-cols-2 gap-1">
              {SPEEDS.map(s => (
                <button
                  key={s.id}
                  onClick={() => update({ speed: s.id })}
                  className={`px-2 py-1.5 rounded-lg text-[10px] font-semibold text-center transition-all ${
                    cfg.speed === s.id
                      ? "bg-blue-500/25 border border-blue-500/50 text-blue-300"
                      : "bg-white/5 border border-white/10 text-gray-400 hover:bg-white/10"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Estilo de resposta */}
          <div>
            <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider mb-1.5">💬 Respostas</p>
            <div className="grid grid-cols-3 gap-1">
              {STYLES.map(s => (
                <button
                  key={s.id}
                  onClick={() => update({ style: s.id })}
                  className={`px-2 py-1.5 rounded-lg text-[10px] font-semibold text-center transition-all ${
                    cfg.style === s.id
                      ? "bg-purple-500/25 border border-purple-500/50 text-purple-300"
                      : "bg-white/5 border border-white/10 text-gray-400 hover:bg-white/10"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Auto-loop */}
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-gray-400">🔁 Conversa automática</span>
            <button
              onClick={() => update({ autoLoop: !cfg.autoLoop })}
              className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all ${
                cfg.autoLoop
                  ? "bg-green-500/20 border border-green-500/40 text-green-400"
                  : "bg-white/5 border border-white/10 text-gray-500"
              }`}
            >
              {cfg.autoLoop ? "Ligado" : "Desligado"}
            </button>
          </div>
        </div>
      )}

      {/* Corpo */}
      <div className="px-3 py-2.5 flex flex-col gap-2 min-h-[60px]">
        {heard && (
          <div className="rounded-xl bg-white/5 border border-white/10 px-3 py-2">
            <p className="text-[9px] text-gray-500 mb-0.5 uppercase tracking-wider">Você disse</p>
            <p className="text-[12px] text-gray-200 leading-snug">{heard}</p>
          </div>
        )}
        {reply && (
          <div className="rounded-xl bg-green-500/5 border border-green-500/20 px-3 py-2">
            <p className="text-[9px] text-green-600 mb-0.5 uppercase tracking-wider">Jasmim</p>
            <p className="text-[12px] text-green-200 leading-snug line-clamp-3">{reply}</p>
          </div>
        )}
        {err && <p className="text-[11px] text-red-400 text-center">{err}</p>}
        <p className={`text-[11px] text-center font-medium ${statusColor}`}>{statusLabel}</p>
      </div>

      {/* Botão principal */}
      <div className="px-3 pb-3">
        <button
          onClick={handleButton}
          disabled={phase === "thinking"}
          className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-[13px] text-white transition-all active:scale-95 disabled:opacity-40 border ${btnColor}`}
        >
          {phase === "thinking" ? (
            <><Loader2 size={15} className="animate-spin" /> Pensando…</>
          ) : phase === "listening" ? (
            <><Square size={14} /> Parar de ouvir</>
          ) : phase === "speaking" ? (
            <><Square size={14} /> Pular resposta</>
          ) : (
            <><Mic size={14} /> Falar</>
          )}
        </button>
      </div>
    </div>
  );
}
