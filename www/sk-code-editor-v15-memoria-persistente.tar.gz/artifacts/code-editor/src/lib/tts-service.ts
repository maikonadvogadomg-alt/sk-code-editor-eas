export interface TTSConfig {
  enabled: boolean;
  lang: string;
  rate: number;
  pitch: number;
  voiceName: string;
}

const DEFAULT_CONFIG: TTSConfig = {
  enabled: true,
  lang: "pt-BR",
  rate: 1.15,
  pitch: 0.95,
  voiceName: "",
};

const PT_BR_VOICE_PRIORITY = [
  "francisca",
  "francisc",
  "luciana",
  "google português do brasil",
  "google português",
  "google pt",
  "portuguese brazil",
  "brazil",
  "pt-br",
  "pt_br",
];

export function loadTTSConfig(): TTSConfig {
  try {
    const saved = localStorage.getItem("tts-config");
    if (saved) return { ...DEFAULT_CONFIG, ...JSON.parse(saved) };
  } catch {}
  return DEFAULT_CONFIG;
}

export function saveTTSConfig(config: TTSConfig) {
  localStorage.setItem("tts-config", JSON.stringify(config));
}

export function getAvailableVoices(lang: string): SpeechSynthesisVoice[] {
  if (!window.speechSynthesis) return [];
  const langBase = lang.split("-")[0].toLowerCase();
  return window.speechSynthesis
    .getVoices()
    .filter(v =>
      v.lang.toLowerCase().startsWith(langBase) ||
      v.lang.toLowerCase() === lang.toLowerCase()
    );
}

function selectBestVoice(voices: SpeechSynthesisVoice[], config: TTSConfig): SpeechSynthesisVoice | null {
  if (!voices.length) return null;
  if (config.voiceName) {
    const byName = voices.find(v => v.name === config.voiceName);
    if (byName) return byName;
  }
  for (const keyword of PT_BR_VOICE_PRIORITY) {
    const found = voices.find(v =>
      v.name.toLowerCase().includes(keyword) ||
      v.lang.toLowerCase().includes(keyword)
    );
    if (found) return found;
  }
  return voices[0] || null;
}

let keepaliveTimer: ReturnType<typeof setInterval> | null = null;

function startKeepalive() {
  if (keepaliveTimer) return;
  keepaliveTimer = setInterval(() => {
    if (window.speechSynthesis?.speaking && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    } else if (!window.speechSynthesis?.speaking) {
      stopKeepalive();
    }
  }, 5000);
}

function stopKeepalive() {
  if (keepaliveTimer) { clearInterval(keepaliveTimer); keepaliveTimer = null; }
}

/**
 * Converte texto com markdown em fala natural.
 * Remove: blocos de código, inline code, # headers, **, URLs, caminhos de arquivo,
 * linhas separadoras, marcadores de lista.
 * Mantém apenas frases conversacionais.
 */
export function cleanForSpeech(rawText: string, maxChars = 800): string {
  let text = rawText;

  // 1. Remove blocos de código (```...```) — substitui por menção breve
  text = text.replace(/```[\s\S]*?```/g, "");

  // 2. Remove inline code (`...`)
  text = text.replace(/`[^`\n]+`/g, "");

  // 3. Remove cabeçalhos markdown (# Título → Título)
  text = text.replace(/^#{1,6}\s+/gm, "");

  // 4. Remove negrito e itálico (**texto** → texto, *texto* → texto)
  text = text.replace(/\*{2,3}([^*\n]+)\*{2,3}/g, "$1");
  text = text.replace(/\*([^*\n]+)\*/g, "$1");
  text = text.replace(/_{2}([^_\n]+)_{2}/g, "$1");

  // 5. Remove URLs
  text = text.replace(/https?:\/\/\S+/g, "");

  // 6. Filtra linha a linha — remove ruído técnico
  const lines = text.split("\n").filter(line => {
    const t = line.trim();
    if (!t) return false;
    // Linhas separadoras (---, ===, ___...)
    if (/^[-─—=*_]{3,}$/.test(t)) return false;
    // Nomes de arquivo isolados (ex: EditorLayout.tsx, src/lib/utils.ts)
    if (/^[\w\-./\\]+\.(ts|tsx|js|jsx|py|json|css|html|md|sh|env|toml|yaml|yml|lock)$/.test(t)) return false;
    // Linhas de código óbvias (começam com {, }, import, export, const, function...)
    if (/^(import|export|const|let|var|function|class|return|if|for|while|async|await)\s/.test(t)) return false;
    // Linhas que são só símbolos
    if (/^[{}[\]();,.<>|&^%$@!]+$/.test(t)) return false;
    return true;
  });

  // 7. Remove marcadores de lista no início
  text = lines.join(" ")
    .replace(/^\s*[-*•]\s+/gm, "")
    .replace(/^\s*\d+\.\s+/gm, "");

  // 8. Limpa espaços múltiplos
  text = text.replace(/\s+/g, " ").trim();

  // 9. Remove frases que são muito curtas ou muito técnicas no meio
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
  const conversational = sentences.filter(s => {
    const clean = s.trim();
    // Ignora frases muito curtas (menos de 5 palavras)
    if (clean.split(" ").length < 3) return false;
    // Ignora frases que parecem código
    if (/[{}\[\]()=><]/.test(clean)) return false;
    return true;
  });

  const result = conversational.length > 0 ? conversational.join(" ") : text;

  // 10. Trunca em limite de caracteres na fronteira de frase
  if (result.length <= maxChars) return result;
  const cut = result.lastIndexOf(".", maxChars);
  return cut > 50 ? result.slice(0, cut + 1) : result.slice(0, maxChars);
}

function doSpeak(text: string, config: TTSConfig): SpeechSynthesisUtterance | null {
  if (!window.speechSynthesis || !text.trim()) return null;

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = config.lang;
  utterance.rate = config.rate;
  utterance.pitch = config.pitch;

  const voices = window.speechSynthesis.getVoices();
  const best = selectBestVoice(voices, config);
  if (best) utterance.voice = best;

  utterance.onstart = () => startKeepalive();
  utterance.onend   = () => stopKeepalive();
  utterance.onerror = () => stopKeepalive();

  window.speechSynthesis.cancel();
  window.speechSynthesis.resume();

  setTimeout(() => {
    window.speechSynthesis.speak(utterance);
  }, 100);

  return utterance;
}

export function speak(text: string, config: TTSConfig): SpeechSynthesisUtterance | null {
  if (!config.enabled || !window.speechSynthesis || !text.trim()) return null;

  const voices = window.speechSynthesis.getVoices();
  if (voices.length > 0) {
    return doSpeak(text, config);
  } else {
    let utteranceRef: SpeechSynthesisUtterance | null = null;
    window.speechSynthesis.onvoiceschanged = () => {
      window.speechSynthesis.onvoiceschanged = null;
      utteranceRef = doSpeak(text, config);
    };
    window.speechSynthesis.getVoices();
    return utteranceRef;
  }
}

export function stopSpeaking() {
  stopKeepalive();
  window.speechSynthesis?.cancel();
}

export function startSpeechRecognition(
  lang: string,
  onResult: (text: string) => void,
  onEnd: () => void
): { stop: () => void } | null {
  const SpeechRecognition =
    (window as any).SpeechRecognition ||
    (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) return null;

  const recognition = new SpeechRecognition();
  recognition.lang = lang;
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onresult = (event: any) => {
    const transcript = event.results[0][0].transcript;
    onResult(transcript);
  };

  recognition.onend = onEnd;
  recognition.onerror = () => onEnd();
  recognition.start();

  return { stop: () => recognition.stop() };
}
